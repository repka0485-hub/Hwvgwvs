#include "common.hpp"
#include "il2cpp.hpp"
#include "hook.hpp"
#include <cmath>
#include <cstdio>

using namespace il2cpp;

Config g_cfg;

namespace {

struct Vec3 { float x, y, z; };

// Class / method handles, resolved by name from the running il2cpp metadata (no hardcoded RVAs).
Il2CppClass* cTouch;
const MethodInfo *mUpdate, *mGetHealth, *mGetIsDeath, *mGetPlayer, *mGetPhoton, *mIsMine,
    *mNick, *mCustomProps, *mHtGetItem, *mGetTransform, *mGetPosition, *mCamMain, *mW2S,
    *mFrameCount, *mScrW, *mScrH, *mFindObjs, *mTouchCount, *mGetTouch;
FieldInfo *fTouchPos, *fTouchPhase;
Il2CppObject* gPcTypeObj;   // UnityEngine.Type of PlayerController (cached by the runtime)
Il2CppObject* gTeamKey;     // pinned managed string "team"

std::mutex g_snapMu;
Snapshot   g_snap;
int        g_lastFrame = -1;
TouchState g_lastTouch;

using UpdateFn = void (*)(void*, const MethodInfo*);
UpdateFn g_origUpdate = nullptr;

bool resolve_failed(const char* what) { LOGE("resolve failed: %s", what); return false; }

#define NEED(dst, expr) do { dst = (expr); if (!(dst)) return resolve_failed(#dst); } while (0)

Vec3 position_of(Il2CppObject* component) {
    Vec3 v{0, 0, 0};
    Il2CppObject* t = call(mGetTransform, component);
    if (t) unbox(call(mGetPosition, t), v);
    return v;
}

bool read_bool(Il2CppObject* o) { uint8_t b = 0; return unbox(o, b) && b; }
int  read_int(Il2CppObject* o)  { int v = 0; unbox(o, v); return v; }

void read_touch(TouchState& t) {
    int n = read_int(call(mTouchCount, nullptr));
    if (n <= 0) {                       // keep last position so a release lands where the finger was
        t = g_lastTouch; t.valid = true; t.down = false; g_lastTouch = t; return;
    }
    int idx = 0; void* a[1] = { &idx };
    Il2CppObject* to = call(mGetTouch, nullptr, a);
    if (!to) return;
    float pos[2] = {0, 0}; int phase = 4;
    A.field_get_value(to, fTouchPos, pos);
    A.field_get_value(to, fTouchPhase, &phase);
    t.valid = true; t.x = pos[0]; t.y = pos[1];
    t.down = phase <= 2;                // Began / Moved / Stationary
    g_lastTouch = t;
}

bool world_to_screen(Il2CppObject* cam, Vec3 w, Vec3& out) {
    void* a[1] = { &w };
    if (!unbox(call(mW2S, cam, a), out)) return false;
    return out.z > 0.01f;
}

void tick() {
    Il2CppObject* fo = call(mFrameCount, nullptr);
    int frame = 0;
    if (!unbox(fo, frame) || frame == g_lastFrame) return;
    g_lastFrame = frame;

    Snapshot s;
    s.frame = (uint64_t)frame;
    s.screenW = read_int(call(mScrW, nullptr));
    s.screenH = read_int(call(mScrH, nullptr));
    read_touch(s.touch);

    static char localTeam[8] = {0};
    int players = 0;

    Il2CppObject* cam = g_cfg.masterEnable ? call(mCamMain, nullptr) : nullptr;
    void* findArgs[1] = { gPcTypeObj };
    Il2CppArray* arr = cam ? (Il2CppArray*)call(mFindObjs, nullptr, findArgs) : nullptr;

    if (arr) {
        Vec3 camPos = position_of(cam);
        Il2CppObject** el = (Il2CppObject**)((char*)arr + kArrayData);
        struct Tmp { EspEntry e; char team[8]; };
        std::vector<Tmp> tmp;

        for (uintptr_t i = 0; i < arr->max_length; ++i) {
            Il2CppObject* pc = el[i];
            if (!pc) continue;
            Il2CppObject* pv = call(mGetPhoton, pc);
            Il2CppObject* pl = call(mGetPlayer, pc);

            char team[8] = {0};
            if (pl) {
                Il2CppObject* props = call(mCustomProps, pl);
                void* keyArgs[1] = { gTeamKey };
                if (props) to_ascii((Il2CppString*)call(mHtGetItem, props, keyArgs), team, sizeof team);
            }
            if (pv && read_bool(call(mIsMine, pv))) {   // local player: remember team, never draw
                memcpy(localTeam, team, sizeof localTeam);
                continue;
            }
            ++players;
            if (read_bool(call(mGetIsDeath, pc))) continue;

            Vec3 feet = position_of(pc);
            float dx = feet.x - camPos.x, dy = feet.y - camPos.y, dz = feet.z - camPos.z;
            float dist = std::sqrt(dx * dx + dy * dy + dz * dz);
            if (dist > g_cfg.maxDistance) continue;

            Vec3 head = feet; head.y += g_cfg.headOffset;
            Vec3 sf, sh;
            if (!world_to_screen(cam, feet, sf) || !world_to_screen(cam, head, sh)) continue;

            Tmp t{};
            t.e.footX = sf.x; t.e.footY = sf.y; t.e.headX = sh.x; t.e.headY = sh.y;
            t.e.dist = dist;
            t.e.health = read_int(call(mGetHealth, pc));
            if (pl) to_ascii((Il2CppString*)call(mNick, pl), t.e.name, sizeof t.e.name);
            memcpy(t.team, team, sizeof t.team);
            tmp.push_back(t);
        }
        for (auto& t : tmp) {
            t.e.teammate = localTeam[0] && strcmp(t.team, localTeam) == 0;
            if (t.e.teammate && !g_cfg.showTeam) continue;
            s.entries.push_back(t.e);
        }
    }
    snprintf(s.status, sizeof s.status, "cam:%s remotes:%d drawn:%zu localTeam:%s",
             cam ? "ok" : "none", players, s.entries.size(), localTeam[0] ? localTeam : "?");

    std::lock_guard<std::mutex> lk(g_snapMu);
    g_snap = std::move(s);
}

// Runs on the Unity main thread (PlayerController.Update); all managed calls happen here.
void hooked_update(void* self, const MethodInfo* mi) {
    g_origUpdate(self, mi);
    tick();
}

} // namespace

bool game_resolve() {
    A.thread_attach(A.domain_get());

    Il2CppClass *cPC, *cPlayer, *cPV, *cHt, *cCam, *cComp, *cTr, *cTime, *cScreen, *cObj, *cInput;
    NEED(cPC,     find_class("", "PlayerController"));
    NEED(cPlayer, find_class("Photon.Realtime", "Player"));
    NEED(cPV,     find_class("Photon.Pun", "PhotonView"));
    NEED(cHt,     find_class("ExitGames.Client.Photon", "Hashtable"));
    NEED(cCam,    find_class("UnityEngine", "Camera"));
    NEED(cComp,   find_class("UnityEngine", "Component"));
    NEED(cTr,     find_class("UnityEngine", "Transform"));
    NEED(cTime,   find_class("UnityEngine", "Time"));
    NEED(cScreen, find_class("UnityEngine", "Screen"));
    NEED(cObj,    find_class("UnityEngine", "Object"));
    NEED(cInput,  find_class("UnityEngine", "Input"));
    NEED(cTouch,  find_class("UnityEngine", "Touch"));

    NEED(mUpdate,      find_method(cPC, "Update", 0));
    NEED(mGetHealth,   find_method(cPC, "get_Health", 0));
    NEED(mGetIsDeath,  find_method(cPC, "get_IsDeath", 0));
    NEED(mGetPlayer,   find_method(cPC, "get_Player", 0));
    NEED(mGetPhoton,   find_method(cPC, "get_Photon", 0));
    NEED(mIsMine,      find_method(cPV, "get_IsMine", 0));
    NEED(mNick,        find_method(cPlayer, "get_NickName", 0));
    NEED(mCustomProps, find_method(cPlayer, "get_CustomProperties", 0));
    NEED(mHtGetItem,   find_method(cHt, "get_Item", 1));
    NEED(mGetTransform,find_method(cComp, "get_transform", 0));
    NEED(mGetPosition, find_method(cTr, "get_position", 0));
    NEED(mCamMain,     find_method(cCam, "get_main", 0));
    NEED(mW2S,         find_method(cCam, "WorldToScreenPoint", 1));
    NEED(mFrameCount,  find_method(cTime, "get_frameCount", 0));
    NEED(mScrW,        find_method(cScreen, "get_width", 0));
    NEED(mScrH,        find_method(cScreen, "get_height", 0));
    NEED(mFindObjs,    find_method(cObj, "FindObjectsOfType", 1));
    NEED(mTouchCount,  find_method(cInput, "get_touchCount", 0));
    NEED(mGetTouch,    find_method(cInput, "GetTouch", 1));
    NEED(fTouchPos,    A.class_get_field_from_name(cTouch, "m_Position"));
    NEED(fTouchPhase,  A.class_get_field_from_name(cTouch, "m_Phase"));

    NEED(gPcTypeObj, A.type_get_object(A.class_get_type(cPC)));
    NEED(gTeamKey,   (Il2CppObject*)A.string_new("team"));
    A.gchandle_new(gTeamKey, true);   // pin for the lifetime of the process

    LOGI("game resolved: PlayerController.Update @ %p", mUpdate->methodPointer);
    return true;
}

bool game_install_hook() {
    void* target = mUpdate->methodPointer;
    if (!install_hook(target, (void*)hooked_update, (void**)&g_origUpdate)) {
        LOGE("hook failed: PlayerController.Update @ %p", target);
        return false;
    }
    LOGI("hooked PlayerController.Update");
    return true;
}

void snapshot_copy(Snapshot& out) {
    std::lock_guard<std::mutex> lk(g_snapMu);
    out = g_snap;
}
