#pragma once
#include <dobby.h>

// Single adapter over the inline-hook backend. Adjust here if the pinned Dobby revision differs.
inline bool install_hook(void* target, void* replacement, void** original) {
    if (!target || !replacement) return false;
    return DobbyHook(target, (dobby_dummy_func_t)replacement, (dobby_dummy_func_t*)original) == 0;
}
